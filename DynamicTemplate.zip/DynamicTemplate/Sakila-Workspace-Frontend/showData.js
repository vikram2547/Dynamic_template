var sUrl = 'http://127.0.0.1:5000'; // URL for middle layer at localhost
var trTemplate = '<tr>{COLS}</tr>';
var tdTemplate = '<td>{VAL}</td>';


var assignmentID='';
$.when($.ready).then(function () {
    showTable();
});

function showTable() {
    displayData();
}

function showForm() {
    document.getElementById("header").innerHTML = '<h1>INSERT DATA</h1>'
        $("#insertButton").hide();
        $("#insertData").show();
        $("#updateData").hide();
        $("#displayData").hide();
}
function insertData() {
        var assign_name = document.getElementById("aname").value;
        var assign_marks = document.getElementById("amarks").value;
        var created_by = document.getElementById("acreatedBy").value;
        
        
        if (assign_name === "" || assign_marks === "" || created_by === "") {
            alert("Please fill in all fields.");
            return;
        }
        else if (!isNaN(parseFloat(assign_name))) {
            alert("Invalid data inserted for 'Name'. Please enter a valid name.");
            return;
        }
        else if (!isNaN(parseFloat(created_by))) {
            alert("Invalid data inserted for 'CreatedBy'. Please enter a valid name.");
            return;
        }
        else{
            alert("Data saved successfully!");
        document.getElementById("aname").value = "";
        document.getElementById("amarks").value = "";
        document.getElementById("acreatedBy").value = "";
        }
        $.ajax({
            url: sUrl,
            type: 'GET',
           //type: 'POST',
            headers: {"option":"insert","aname": assign_name, "amarks":assign_marks, "acreatedBy":created_by},
            success: function(result) {
                $("#insertData").hide();
                $("#displayData").show();
                $("#displayData").html(result)
                
                $.ajax({
                    url: sUrl,
                    type: 'GET',
                    headers: {"option": "display"},
                    
                    success: function(result) {
                        $("#insertData").hide();
                        $("#insertButton").show();
                        $("#displayData").show();
                        $("#displayData").html(result);
                        
                    }
                });
            }
        });
    
}

function updateData() {
    //var assign_id = document.getElementById("assignid").value;
    var assign_name = document.getElementById("name").value;
    var assign_marks = document.getElementById("marks").value;
    var modified_by = document.getElementById("modifiedBy").value;
    var assign_id = assignmentID;
    
    if (assign_name === "" || assign_marks === "" || modified_by === "") {
        alert("Please fill in all fields.");
        return;
    }
    else{alert("Data saved successfully!");
            document.getElementById("name").value = "";
            document.getElementById("marks").value = "";
            document.getElementById("modifiedBy").value = "";
    }
   
    $.ajax({
        url: sUrl,
        type: 'GET',
       //type: 'POST',
        headers: {"option":'update',"assignid":assign_id, "name": assign_name, "marks":assign_marks, "modifiedBy":modified_by},
        success: function(result) {
            $("#updateData").hide();
            $("#displayData").show();
            $("#displayData").html(result)
            
            $.ajax({
                url: sUrl,
                type: 'GET',
               //type: 'POST',
                headers: {"option":"display"},
                success: function(result) {
                    console.log(result);
                    $("#insertButton").show();
                    $("#insertData").hide();
                    $("#updateData").hide();
                    $("#displayData").show();
                    $("#displayData").html(result)
                    
                }
            });
        }
        
    });
    
}

function displayData() {
    $("#displayData").show();
    

    $.ajax({
        url: sUrl,
        type: 'GET',
       //type: 'POST',
        headers: {"option":"display"},
        success: function(result) {
            console.log(result);
            document.getElementById("header").innerHTML = '<h1>DISPLAY DATA</h1>'
            $("#insertButton").show();
            $("#insertData").hide();
            $("#updateData").hide();
            $("#displayData").show();
            $("#displayData").html(result)
        }
    });
}

function editData(assign_id, assign_name, assign_marks, created_by, modified_by) {
    console.log("id");
    assignmentID = assign_id;
    console.log("assignid:", assign_id);
    console.log("name:", assign_name);
    console.log("marks:", assign_marks);
    console.log("createdBy:", created_by);
    console.log("modifiedBy:", modified_by);
    $("#insertButton").hide();
    $("#displayData").hide();
    $("#updateData").show();
    document.getElementById("header").innerHTML = '<h1>UPDATE DATA</h1>'
    document.getElementById("name").value = assign_name;
    document.getElementById("marks").value = assign_marks;
    document.getElementById("modifiedBy").value = modified_by;
    
}

function DeleteData(assign_id) {
    console.log("assignid:", assign_id);
        $.ajax({
            url: sUrl,
            type: 'GET',
            headers: {
                "option": "delete",
                "assignid": assign_id
            },
            success: function(result) {
                $("#displayData").show();
                displayData();
            }
        });
    }



// End of JSON HTML

// Start of without JSON HTML

// function getData(){
//     $.ajax({
//         url: sUrl,
//         type: 'GET',
//         success: function(result) {
//             let finalResult = ''
//             console.log(result)
//             for(let e in result){
//                 let data = result[e];
                
//                 finalResult = finalResult + createTable(data);
//             }
            
//             $("#showData").show();
//             $("#showDataRows").html(finalResult);
//             $("#viewData").show();
//             $("#viewDataRows").html(finalResult);
//         }
//     });  /
// }

// // Function to create table
// function createTable(pData){
//     let tdData = '';
//     let trData = '';
//     for(let e in pData){
//         tdData = tdData + tdTemplate.replace('{VAL}', pData[e])
//     }
//     trData = trData + trTemplate.replace('{COLS}', tdData);
//     // console.log(trData);

//     return trData;
// }


// End of without JSON HTML
