# Constants requires throughout this projects, add here
CONSTANTS = {
    "HOST": "localhost",
    "USER": "root",
    "PASSWORD": "Vikram@123",
    "DATABASE": "sakila",

    "sql_Get_Data_WithJSON": "SELECT JSON_OBJECT( 'category_id', category_id, 'name', name) AS jData FROM (SELECT category_id, name FROM category) AS dData;",
    "sql_Get_Data_WithJSON_Two": "SELECT JSON_OBJECT('assignid', assign_id, 'assignname', assign_name, 'assignmarks', assign_marks, 'createdby', created_by, 'modifiedby', modified_by) AS jData FROM (SELECT CAST(assign_id AS CHAR (11)) AS assign_id, assign_name, CAST(assign_marks AS CHAR (11)) AS assign_marks, IFNULL(created_by, '-') AS created_by, IFNULL(modified_by, '-') AS modified_by FROM assignment) AS dData;",
    "INSERT_ASSIGNMENT":"INSERT INTO assignment(assign_name,assign_marks,created_by,created_date)VALUES('{}' ,'{}' ,'{}' ,now())",
    #"UPDATE_ASSIGNMENT":"UPDATE assignment set assign_name ='{}', assign_marks='{}', modified_by='{}', modified_date = now() where assign_id =1;",
    "UPDATE_ASSIGNMENT": "UPDATE assignment SET assign_name = '{}', assign_marks = '{}', modified_by = '{}', modified_date = NOW() WHERE assign_id = '{}';",
    "DELETE_ASSIGNMENT": "DELETE FROM assignment WHERE assign_id = '{}';"


    }


