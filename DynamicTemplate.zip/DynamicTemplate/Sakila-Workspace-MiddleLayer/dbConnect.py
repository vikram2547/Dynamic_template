# import mysql.connector
import pymysql
from constants import CONSTANTS
from flask import request
from flask import Flask
from flask_cors import cross_origin
import json

# Flask constructor takes the name of
# current module (__name__) as argument.
app = Flask(__name__)

@app.route('/')
@cross_origin()
def assignData():
    
  try:
    # Database connectivity - Change user and password accordingly
    mydb = pymysql.connect(
    host= CONSTANTS['HOST'],
    user= CONSTANTS['USER'],
    password= CONSTANTS['PASSWORD'],
    db= CONSTANTS['DATABASE']
    )
    option = request.headers['option']
    
    
    if(option == "insert"):
      assign_name = request.headers['aname']
      assign_marks = request.headers['amarks']
      created_by = request.headers['acreatedBy']
      InsertSql = CONSTANTS['INSERT_ASSIGNMENT'].format(assign_name, assign_marks, created_by)
      insertTable(mydb, InsertSql)
      return "insert"
    
    elif(option == "update"):
      assign_id = request.headers['assignid']
      assign_name = request.headers['name']
      assign_marks = request.headers['marks']
      modified_by = request.headers['modifiedBy']
      UpdateSql = CONSTANTS['UPDATE_ASSIGNMENT'].format(assign_name, assign_marks, modified_by, assign_id)
      updateTable(mydb, UpdateSql)
      return "update"
  
    elif(option == "display"):
      sql = CONSTANTS['sql_Get_Data_WithJSON']
      mycursor = mydb.cursor()
      mycursor.execute(sql)

      myresult = mycursor.fetchall()
      result = generateTemplate(myresult)

      sql = CONSTANTS['sql_Get_Data_WithJSON_Two']
      mycursor = mydb.cursor()
      mycursor.execute(sql)

      myresult = mycursor.fetchall()
      result += generateTemplate(myresult)
      return result


    elif option == "delete":
      assign_id = request.headers['assignid']
      DeleteSql = CONSTANTS['DELETE_ASSIGNMENT'].format(assign_id)
      deleteTable(mydb, DeleteSql)
      return "deleted"

  
  except Exception as e:
    print(str(e.args))
    return str(e)
    

# Generating table from JSON Data as query result
# def generateTemplate(pData):
#   trTemplate = '<table style="width:100%;"> <thead> <tr> <th>assign_name</th> <th>assign_marks</th> <th>created_by</th> <th>modified_by</th> <th>action</th> </tr> </thead> {LINES} </tbody> </table>'
#   tdTemplate = '<tr><td>{ASSIGNNAME}</td><td>{ASSIGNMARKS}</td><td>{CREATEDBY}</td><td>{MODIFIEDBY}</td><td><button onclick=editData("{ASSIGNID}","{ASSIGNNAME}","{ASSIGNMARKS}","{MODIFIEDBY}") style="color: rgb(10, 122, 47);">Edit</button><button onclick=DeleteData("{ASSIGNID}") style="color: rgb(241, 10, 10);">Delete</button></td></tr>'
#   final_merge = ''
#   for e in pData:
#     tp = tuple(e)
#     str_merge = tdTemplate
#     for t in tp:
#       jData = json.loads(t)
#       keys = jData.keys()
#       for key in keys:
#         u = '{' + key.upper() + '}' 
#         str_merge = str_merge.replace(u, jData[key])
#       final_merge += str_merge
#   outer_html = trTemplate.replace('{LINES}', final_merge)
#   return outer_html

def generateTemplate(pData):
    trTemplate = '<table style="width:100%;"><thead>{HEADINGS}</thead><tbody>{LINES}</tbody></table>'
    tdTemplate = ''
    
    pHeadings = []
    
    if pData:
        # Get keys from tuple in pData
        pHeadings = json.loads(pData[0][0]).keys()# [0][0] denotes element of row is in json string and json.loads covert string into python
        
        # Generate the tdTemplate dynamically based on the keys
        tdTemplate = ''
        for heading in pHeadings:
            tdTemplate += '<td>{{' + heading.upper() + '}}</td>'
    
    heading_row = '<tr>'
    for heading in pHeadings:
        heading_row += '<th>' + heading + '</th>'
    heading_row += '</tr>'
    
    data_rows = ''
    for data in pData:
        str_merge = '<tr>' + tdTemplate + '</tr>'
        for t in data:
            jData = json.loads(t)
            for key in pHeadings:
                placeholder = '{{' + key.upper() + '}}'
                str_merge = str_merge.replace(placeholder, str(jData.get(key, ''))) 
        data_rows += str_merge
    
    outer_html = trTemplate.replace('{HEADINGS}', heading_row)
    outer_html = outer_html.replace('{LINES}', data_rows)
    return outer_html



def insertTable(connection, givenSQL =None):
  e_sql = givenSQL
  try:
    cursor = connection.cursor()
    cursor.execute(e_sql)
    connection.commit()
    return cursor.lastrowid
  except Exception as e:
    # print(str(e.args))
    return str(e)

def updateTable(connection, givenSQL =None):
  e_sql = givenSQL
  try:
    cursor = connection.cursor()
    cursor.execute(e_sql)
    connection.commit()
    return cursor.rowcount
  except Exception as e:
    # print(str(e.args))
    return str(e)
  
def deleteTable(connection, givenSQL =None):
  e_sql = givenSQL
  try:
    cursor = connection.cursor()
    cursor.execute(e_sql)
    connection.commit()
    return cursor.rowcount
  except Exception as e:
    # print(str(e.args))
    return str(e)

# main driver function
if __name__ == '__main__':
    # run() method of Flask class runs the application
    # on the local development server.
    app.run()